<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/svpstats?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_actualiser_stats' => 'Actualiseer de statistieken',
	'bulle_actualiser_stats' => 'Actualiseer de statistieken van de plugins',

	// I
	'info_actualisation_stats_cron' => 'De gebruiksstatistieken van plugins worden automatisch elke @periode@ dag(en) geactualiseerd.',
	'info_boite_statistiques' => '<strong>Je hebt de gebruiksstatistieken van de plugins geactiveerd.</strong><p>Deze worden elke @periode@ dag(en) geactualiseerd. Maar je kunt op ieder moment een actualisatie forceren.</p>',
	'info_nbr_sites_0' => 'In geen enkele site gebruikt',
	'info_nbr_sites_1' => 'In 1 site gebruikt',
	'info_nbr_sites_n' => 'In @nb@ sites gebruikt'
);
