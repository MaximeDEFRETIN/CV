<?php
// Exportation config SPIP Proprio
// Site d'origine : Maxime Defretin
// Cree le : 2020-02-21 10:47:16

$proprio_config = array (
  'proprietaire_nom' => 'Maxime Defretin',
  'proprietaire_libelle' => 'Site personnel',
  'proprietaire_mail' => 'maxime.defretin@laposte.net',
  'proprietaire_nom_responsable' => 'Maxime Defretin',
  'proprietaire_fonction_responsable' => 'Propriétaire',
  'proprietaire_mail_responsable' => 'maxime.defretin@laposte.net',
  'proprietaire_mail_administratif' => 'maxime.defretin@laposte.net',
  'proprietaire_site_web' => 'http://',
  'copyright_annee' => '',
  'copyright_complement' => '',
  'copyright_comment' => '',
  'hebergeur_legal_forme' => 'SAS',
  'hebergeur_legal_abbrev' => '',
  'hebergeur_legal_genre' => 'fem',
  'hebergeur_enregistrement_organisme' => 'RCS de Lille',
  'hebergeur_enregistrement_abbrev' => '',
  'hebergeur_enregistrement_genre' => 'fem',
  'hebergeur_enregistrement_numero' => '424 761 419 00045',
  'hebergeur_enregistrement_siren' => '',
  'hebergeur_enregistrement_siret' => '',
  'hebergeur_enregistrement_tvaintra' => '',
  'hebergeur_enregistrement_tva_nonapplicable' => false,
  'hebergeur_capital_social' => '10 069 020 €',
  'hebergeur_nom' => 'OVH',
  'hebergeur_libelle' => 'SAS',
  'hebergeur_mail' => 'maxime.defretin@laposte.net',
  'hebergeur_nom_responsable' => 'Henryk KLABA',
  'hebergeur_fonction_responsable' => 'Président',
  'hebergeur_mail_responsable' => NULL,
  'hebergeur_mail_administratif' => NULL,
  'hebergeur_site_web' => 'https://www.ovh.com',
  'createur_nom' => 'Maxime Defretin',
  'createur_libelle' => 'Site personnel',
  'createur_mail' => 'maxime.defretin@laposte.net',
  'createur_nom_responsable' => 'Maxime Defretin',
  'createur_fonction_responsable' => 'Propriétaire',
  'createur_mail_responsable' => NULL,
  'createur_mail_administratif' => NULL,
  'createur_site_web' => 'https://w-l.fr',
  'createur_administrateur' => 'oui',
);

?>