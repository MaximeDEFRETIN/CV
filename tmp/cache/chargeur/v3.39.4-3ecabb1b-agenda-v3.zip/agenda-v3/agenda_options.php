<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

// brancher le plugin sur nospam
$GLOBALS['formulaires_no_spam'][] = 'participer_evenement';
