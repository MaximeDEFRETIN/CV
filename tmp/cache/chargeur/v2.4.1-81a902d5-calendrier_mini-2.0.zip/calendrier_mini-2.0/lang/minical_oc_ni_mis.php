<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/minical?lang_cible=oc_ni_mis
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_date' => 'Mìnga per aqueu mès',

	// C
	'config_titre_calendriermini' => 'Mini-Calendari',

	// L
	'label_affichage_hors_mois' => 'Jou afichat',
	'label_affichage_hors_mois_0' => 'Escoundre lu jou dei mès prechedent e seguent',
	'label_affichage_hors_mois_1' => 'Afichà lu jou dei mès prechedent e seguent',
	'label_changement_rapide' => 'Navigacioun',
	'label_changement_rapide_0' => 'Desativà la selecioun rapida dóu mès o de l’anada',
	'label_changement_rapide_1' => 'Ativà la selecioun rapida dóu mès o de l’anada',
	'label_format_jour' => 'Fourmat dei jou',
	'label_format_jour_abbr' => 'Court',
	'label_format_jour_initiale' => 'Iniciala',
	'label_jour1' => 'Premié jou de la semana',

	// M
	'mois_precedent' => 'Mès prechedent',
	'mois_suivant' => 'Mès seguent'
);
