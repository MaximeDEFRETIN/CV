<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-corbeille?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille_description' => 'Este plugin permite alterar o comportamento padrão do SPIP, que remove automaticamente certos objetos da base de dados (matérias, notas... na lixeira), após um ou dois dias.

Com este plugin, nenhum objeto é removido automaticamente. A lixeira guarda todas as matérias ou outros objetos que você tenha apagado, e você poderá sempre voltar atrás.',
	'corbeille_nom' => 'Lixeira',
	'corbeille_slogan' => 'Gerenciamento de documentos colocados na lixeira'
);
