<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-calendriermini?lang_cible=ja
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'calendriermini_description' => '#CALENDRIER_MINIは、dotclearデザインのカレンダーを表示しますから、このブログシステムのスタイルと互換性があります。
タグ、条件、モデルなど、他の要素が追加されました...',
	'calendriermini_nom' => 'ミニカレンダー',
	'calendriermini_slogan' => '#CALENDRIER_MINIタグを使用する許可です。'
);
