<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'يسهّل هذا الملحق إنشاء حقول للاستمارات من خلال توفيره علامة SAISIE#. تتوافق علامات HTML الناتجة مع تسمية الاستمارات 
		المقترحة في SPIP بإصداراته الأحدث من ٢.٠ ومع ملحق الاعدادات CFG.',
	'saisies_nom' => 'إدخال للاستمارات',
	'saisies_slogan' => 'إنشاء حقول استمارات بسهولة',
	'saisies_titre' => 'إدخال للاستمارات'
);
