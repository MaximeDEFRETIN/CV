<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-article_accueil?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'article_accueil_description' => 'Tento zásuvný modul vám umožňuje určiť, ktorý článok bude titulný článok rubriky. Pole id_article_accueil potom môžete použiť v šablónach.',
	'article_accueil_nom' => 'Titulné články',
	'article_accueil_slogan' => 'Určte titulné články rubrík'
);
