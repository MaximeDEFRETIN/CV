<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-pages?lang_cible=ru
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'pages_description' => 'Данный плагин позволяет создавать отдельные страницы вне любых разделов сайта. Это отличное решения для размещения контактной информации, условий и правил использования, а так же для любой информации, которая логически не встраивается в структуру сайта.
Cela permet notamment de créer des pages de notice légale, d’à-propos, de contact, etc.',
	'pages_slogan' => 'Отдельные страницы'
);
