<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-metasplus?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'metasplus_description' => 'Improve the indexing of your articles in search engines and their display on social networks with Dublin Core, Open Graph and Twitter Card metadata.',
	'metasplus_slogan' => 'Metadata for Open Graph, Duclin Core and Twitter'
);
