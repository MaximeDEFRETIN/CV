<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-pages?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'pages_description' => 'Este plugin permite crear páginas de artículos que no están asociadas a ninguna jerarquía particular.
Por contra, pueden asociarse a un nombre de esqueleto. Ello permite crear páginas de aviso legal, acerca de, contacto, etc.',
	'pages_slogan' => 'Páginas sin sección'
);
