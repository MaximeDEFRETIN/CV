<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-simplog?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'simplog_description' => 'Ak je zásuvný modul aktivovaný, administrátori majú možnosť prezrieť si všetky protokoly, ktoré sú na stránke dostupné. Vstup do menu údržby umožňuje navštíviť stránku na prezeranie protokolov.',
	'simplog_nom' => 'Jednoduché protokoly',
	'simplog_slogan' => 'Zobrazenie protokolov SPIPu pre  administrátorov'
);
