<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/article_accueil?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'article_accueil' => 'Matéria de boas vindas',
	'aucun_article_accueil' => 'Nenhuma matéria',

	// L
	'label_id_article_accueil' => 'Escolher uma matéria',

	// R
	'rubrique_article_en_accueil' => 'Matéria de boas-vindas:'
);
