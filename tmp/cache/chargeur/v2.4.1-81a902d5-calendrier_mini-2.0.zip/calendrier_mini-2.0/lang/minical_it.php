<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/minical?lang_cible=it
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_date' => 'Niente per questo mese',

	// C
	'config_titre_calendriermini' => 'Mini Calendario',

	// L
	'label_affichage_hors_mois' => 'Giorni visualizzati',
	'label_affichage_hors_mois_0' => 'Nascondi i giorni dei mesi precedenti e futuri',
	'label_affichage_hors_mois_1' => 'Visualizza i giorni dei mesi precedenti e futuri',
	'label_changement_rapide' => 'Navigazione',
	'label_changement_rapide_0' => 'Disabilita la selezione rapida del mese o dell’anno',
	'label_changement_rapide_1' => 'Abilita la selezione rapida del mese o dell’anno',
	'label_format_jour' => 'Formato dei giorni',
	'label_format_jour_abbr' => 'Corto',
	'label_format_jour_initiale' => 'Lettera iniziale',
	'label_jour1' => 'Primo giorno della settimana',

	// M
	'mois_precedent' => 'Mese precedente',
	'mois_suivant' => 'Mese successivo'
);
