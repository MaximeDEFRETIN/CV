<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-corbeille?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille_description' => 'Deze plugin laat je toe af te wijken van het standaard gedrag van SPIP om bepaalde objecten automatisch na enkele dagen uit de database te verwijderen (artikelen, nieuwsberichten... in de prullenbak).

Met deze plugin wroden objecten niet langer automatisch verwijderd. Alle artikelen en andere objecten blijven in de prullenbak bewaard en je kunt ze er altijd weer uit halen.',
	'corbeille_nom' => 'Prullenbak',
	'corbeille_slogan' => 'Beheer van documenten in de prullenbak'
);
