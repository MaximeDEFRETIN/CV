<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'Met behulp van deze plugin komt de functie van het lezen/schrijven in YAML-formaat beschikbaar:
	<code>yaml_decode()</code> en <code>yaml_encode()</code>. Het formaat kan ook in de (DATA) lus worden gebruikt.',
	'yaml_slogan' => 'Een eenvoudig bestandsformaat om gegevenslijsten te redigeren'
);
