<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-calendriermini?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'calendriermini_description' => '#CALENDRIER_MINI exibe um calendário com o design do dotclear e portanto compatível com os estilos desse sistema de blog.
_ Foram incluídos outros elementos, como tags, critérios, modelos...',
	'calendriermini_nom' => 'Mini Calendário',
	'calendriermini_slogan' => 'Permite o uso de uma tag #CALENDRIER_MINI'
);
