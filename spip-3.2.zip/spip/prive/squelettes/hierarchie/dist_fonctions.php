<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

include_spip('inc/pipelines_ecrire');
