<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip-contrib-extensions/svp_stats.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_actualiser_stats' => 'Actualiser les statistiques',
	'bulle_actualiser_stats' => 'Actualiser les statistiques des plugins',

	// I
	'info_actualisation_stats_cron' => 'Les statistiques d’utilisation des plugins sont actualisées automatiquement tous les @periode@ jour(s).',
	'info_boite_statistiques' => '<strong>Vous avez activé les statistiques d’utilisation des plugins.</strong><p>Celles-ci sont actualisées tous les @periode@ jour(s). Néanmoins, vous avez la possibilité de lancer, à tout moment, une mise à jour manuelle.</p>',
	'info_nbr_sites_0' => 'Utilisé dans aucun site',
	'info_nbr_sites_1' => 'Utilisé dans 1 site',
	'info_nbr_sites_n' => 'Utilisé dans @nb@ sites'
);
