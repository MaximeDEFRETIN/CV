Un jeu de squelettes proposant un affichage en 2 ou 3 colonnes
avec un large choix de noisettes à insérer ou pas,
fortement paramétrable depuis l’espace privé :
-  choix de la mise en page (position des colonnes, fluide ou pas)
-  choix de la présence (ou absence) des blocs latéraux et centraux, choix de leur colonne et choix de leur ordre
-  choix de l’image de fond et de l’image du bandeau
-  choix des couleurs de fond, du texte et des bords
-  choix du menu
-  choix de la zone d’identification
-  présence ou absence de certains éléments (ombres latérales, titre du site dans le bandeau ...)
-  choix des arrondis
- etc

Codé en HTML5 et décliné en plusieurs langues.

Permet l’affichage d’un bouton de paramétrage de l’accessibilité visuelle.

Nécessite les plugins "Agenda" , "Calendrier-mini" et "svpstats".