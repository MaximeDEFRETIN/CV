<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-escal?lang_cible=sq
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// E
	'escal_description' => 'Të përshtatshme për versionin 3 të SPIP, ajo ofron:
-* një konfiguracion shtyjnë në zonë private
-* një plan urbanistik configurable në 2 ose 3 kolona duke zgjedhur një fletë stil 
-* menaxhimin e shumëgjuhësinë
-* style thjeshtë phpBB
-* një përzgjedhje të gjerë të arrave për të mbajtur apo jo, disa prej të identifikimit të tepërta, menu horizontale dhe / ose vertikale.
-* në vend të kësaj, ngjyra dhe përmbajtje të lehtë për të ndryshuar blloqe anësore
-* një menu horizontale dhe / ose vertikale (zgjedhja 2) të bjerë me zhvillimin e temës aktuale
-* redirection automatik të shkrimit, nëse ai është i vetëm në kolonën e tij
-* navigacion nga fjalë kyçe
-* një kalendar dhe / ose një listë e ngjarjeve
-* një shfaqje e artikujt e fundit apo artikujve në të njëjtin seksion
-* ën-kategori ekran dhe sende në çdo faqe kategori
-* a artikuj ekranit Forumet
-* Autorët e një të kontaktit në qoftë se ata të listuara email e tyre
-* një kontakt të zhvilluar
-* një sitemap
-* një fotografi backend për faqen syndication
-* une feuille de style spéciale pour l&#39;impression des articles
-* një zonë lidhje në faqen kryesore (2 zgjedhje viewing)
-* vendosur një XHTML valide 1.0 strikte', # MODIF
	'escal_slogan' => 'Skelet 2 ose 3 kolona përbërë nga shumë lajthi'
);
