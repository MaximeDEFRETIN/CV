<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-corbeille?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille_description' => 'Este plugin permite derogar el comportamiento estándar de SPIP que borra automáticamente ciertos objetos de la base de datos (artículos, breves... a la papelera), en un plazo de uno o dos días.

Con este plugin, ningún objeto volverá a ser eliminado automáticamente. La papelera guarda todos los artículos u otros objetos que hay metido en ella, y puede siempre deshacer la acción. ',
	'corbeille_nom' => 'Papelera',
	'corbeille_slogan' => 'Gestión de los documentos enviados a la papelera.'
);
