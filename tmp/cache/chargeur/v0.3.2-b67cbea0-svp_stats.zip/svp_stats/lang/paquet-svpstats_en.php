<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-svpstats?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'svpstats_description' => 'This plugin is an optional module of SVP. 
_ It allows you to acquire, update and return the usage statistics of SPIP plugins on the Internet.
Those statistics come from the <a href="http://stats.spip.org">stats.spip.org</a> Web site.',
	'svpstats_slogan' => 'SVP module to manage the usage statistics of the plugins'
);
