<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Este plugin permite facilitar a escrita de campos de formulários, propondo uma tag #SAISIE. O HTML gerado é compatível com a nomenclatura dos formulários propostos pelo SPIP > 2.0 e com o plugin de configuração CFG.',
	'saisies_nom' => 'Entradas para formulários',
	'saisies_slogan' => 'Facilitar a entrada de dados em campos de formulários.',
	'saisies_titre' => 'Entrada de dados para formulários'
);
