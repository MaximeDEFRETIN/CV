<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/minical?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_date' => 'Nič na tento mesiac',

	// C
	'config_titre_calendriermini' => 'Minikalendár',

	// L
	'label_affichage_hors_mois' => 'Zobrazené dni',
	'label_affichage_hors_mois_0' => 'Schovať dni predchádzajúceho a ďalšieho mesiaca',
	'label_affichage_hors_mois_1' => 'Zobraziť dni predchádzajúceho a nasledujúceho mesiaca',
	'label_changement_rapide' => 'Navigácia',
	'label_changement_rapide_0' => 'Deaktivovať rýchly výber mesiaca alebo roka',
	'label_changement_rapide_1' => 'Aktivovať rýchly výber mesiaca alebo roka',
	'label_format_jour' => 'Formát dní',
	'label_format_jour_abbr' => 'Krátky',
	'label_format_jour_initiale' => 'Začiatočné písmeno',
	'label_jour1' => 'Prvý deň v týždni',

	// M
	'mois_precedent' => 'Predchádzajúci mesiac',
	'mois_suivant' => 'Ďalší mesiac'
);
