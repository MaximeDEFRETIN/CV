<?php

if (!defined('_ECRIRE_INC_VERSION')) return;

include_spip('inc/json');

function todate($t){return date('Y-m-d H:i:s',$t);}
