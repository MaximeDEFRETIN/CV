<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-corbeille?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille_description' => 'This plugin allows you to deviate from the standard SPIP behaviour to automatically delete certain objects from the database (articles, news... to the trash), with a delay of one or two days.

With this plugin none of the objects is deleted automatically. The basket keeps all articles or other objects that have been put in and you can always reverse it.',
	'corbeille_nom' => 'Recycle bin',
	'corbeille_slogan' => 'Managing documents chucked in the recycle bin.'
);
