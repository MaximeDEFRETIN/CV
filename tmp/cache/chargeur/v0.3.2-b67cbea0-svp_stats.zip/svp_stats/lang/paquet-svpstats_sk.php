<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-svpstats?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'svpstats_description' => 'Tento zásuvný modul je nepovinným modulom SVP.
 _ Umožňuje vám zistiť, aktualizovať a vypísať štatistiky využívania zásuvných modulov SPIPu na internete.
 Tieto štatistiky pochádzajú zo stránky <a href="http://stats.spip.org">stats.spip.org.</a>',
	'svpstats_slogan' => 'Modul SVP na správu štatistík využívania zásuvných modulov'
);
