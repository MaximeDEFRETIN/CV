<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Deze plugin vereenvoudigt het maken van formuliervelden danzij een code #SAISIE. De gegenereerde HTML is compatibel met die van SPIP formulieren vanaf versie 2.0 en met de configuratie plugin CFG.',
	'saisies_nom' => 'Saisies (Invoer) voor formulieren',
	'saisies_slogan' => 'Eenvoudig formuliervelden maken.',
	'saisies_titre' => 'Invoer voor formulieren'
);
