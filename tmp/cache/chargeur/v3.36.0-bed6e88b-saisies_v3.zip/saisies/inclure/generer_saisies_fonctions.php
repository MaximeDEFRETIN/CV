<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

if (!defined('_SAISIES_AFFICHER_SI_JS_SHOW')) {
	define ('_SAISIES_AFFICHER_SI_JS_SHOW', 'show(400)');
}
if (!defined('_SAISIES_AFFICHER_SI_JS_HIDE')) {
	define ('_SAISIES_AFFICHER_SI_JS_HIDE', 'hide(400)');
}
