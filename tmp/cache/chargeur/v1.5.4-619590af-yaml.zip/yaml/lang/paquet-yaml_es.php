<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'Este plugin proporciona las funciones de lectura/escritura del formato YAML: <code>yaml_decode()</code> y <code>yaml_encode()</code>. También proporciona el formato yaml para el bucle (DATA).',
	'yaml_slogan' => 'Un formato de archivo simple para editar listas de datos'
);
