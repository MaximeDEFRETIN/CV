<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'This plugin makes it easier to write form fields by providing a #SAISIE tag. 
		The generated HTML is compatible with the classification of forms
		proposed by SPIP > 2.0 and with the configuration plugin CFG.',
	'saisies_nom' => 'Entries for forms',
	'saisies_slogan' => 'Create easily forms fields.',
	'saisies_titre' => 'Entries for forms'
);
