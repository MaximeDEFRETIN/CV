<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip-contrib-extensions/simplog.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'simplog_description' => 'Une fois le plugin activé, les administrateurs ont la possibilité de consulter tous les journaux disponibles sur le site. Une entrée du menu Maintenance permet de se rendre sur la page de consultation.',
	'simplog_nom' => 'Simples Logs',
	'simplog_slogan' => 'Visualisation des logs SPIP par les administrateurs'
);
