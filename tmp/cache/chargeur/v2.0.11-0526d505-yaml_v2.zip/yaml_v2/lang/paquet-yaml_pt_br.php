<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-yaml?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// Y
	'yaml_description' => 'Este plugin fornece as funções de leitura/escrita do formato YAML : <code>yaml_decode()</code> e <code>yaml_encode()</code>. Ele fornece também o formato yaml para o laço (DATA).',
	'yaml_slogan' => 'Um formato de arquivo simples para editar listas de dados'
);
