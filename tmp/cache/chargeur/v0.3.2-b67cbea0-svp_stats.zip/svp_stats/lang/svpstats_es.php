<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/svpstats?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_actualiser_stats' => 'Actualizar las estadísticas',
	'bulle_actualiser_stats' => 'Actualizar las estadísticas de los plugins',

	// I
	'info_actualisation_stats_cron' => 'Las estadísticas de utilización de los plugins son actualizados automáticamente todos los  @periode@ día(s).',
	'info_boite_statistiques' => '<strong>Ha activado las estadísticas de utilización de los plugins.</strong><p>Éstas son actualizadas todos los @periode@ día(s). No obstante, tiene la posibilidad de lanzar en todo momento una actualización manual.</p>',
	'info_nbr_sites_0' => 'Utilizado en ningún sitio',
	'info_nbr_sites_1' => 'Utilizado en 1 sitio',
	'info_nbr_sites_n' => 'Utilizado en @nb@ sitios'
);
