# Plugin Métas+ : choses à faire

## Open graph

### Propriétés

article:section : rubriques

## Twitter

### propriétés

twitter:site : en fonction des plugins installés, il y a peut-être moyen de renseigner le compte twitter


## Dublin Core

Lire la doc !
Prendre le plugin dublin core comme référence aussi.