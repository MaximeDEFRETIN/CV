<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/svpstats?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_actualiser_stats' => 'Refresh the statistics',
	'bulle_actualiser_stats' => 'Refresh the plugins statistics',

	// I
	'info_actualisation_stats_cron' => 'Plugins usage statistitics are updated every @periode@ day(s).',
	'info_boite_statistiques' => '<strong>You have enabled the plugins usage statistics.</strong><p>Those are updated every @periode@ day(s). But you can start, at any time, a manual update.</p>',
	'info_nbr_sites_0' => 'Used in no Web site',
	'info_nbr_sites_1' => 'Used in 1 Web site',
	'info_nbr_sites_n' => 'Used in @nb@ Web sites'
);
