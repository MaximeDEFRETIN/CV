<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-article_accueil?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'article_accueil_description' => 'Este plugin permite atribuir um a matéria principal às seções. O campo id_article_accueil pode, em seguida, ser usado pelos templates.',
	'article_accueil_nom' => 'Matérias principais',
	'article_accueil_slogan' => 'Atribuir uma matéria principal às seções'
);
