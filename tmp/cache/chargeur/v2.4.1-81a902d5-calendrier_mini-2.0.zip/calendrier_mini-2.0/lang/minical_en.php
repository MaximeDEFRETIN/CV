<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/minical?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_date' => 'Nothing for this month',

	// C
	'config_titre_calendriermini' => 'Mini-Calendar',

	// L
	'label_affichage_hors_mois' => 'Days displayed',
	'label_affichage_hors_mois_0' => 'Hide days of previous and next months',
	'label_affichage_hors_mois_1' => 'Display days of previous and next months',
	'label_changement_rapide' => 'Navigation',
	'label_changement_rapide_0' => 'Enable quick selection of the month or year.',
	'label_changement_rapide_1' => 'Enable quick selection of the month or year.',
	'label_format_jour' => 'Days format',
	'label_format_jour_abbr' => 'Short',
	'label_format_jour_initiale' => 'Initial letter',
	'label_jour1' => 'First day of the week',

	// M
	'mois_precedent' => 'Previous month',
	'mois_suivant' => 'Next month'
);
