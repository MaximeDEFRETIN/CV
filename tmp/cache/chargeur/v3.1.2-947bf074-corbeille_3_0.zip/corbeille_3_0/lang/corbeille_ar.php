<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/corbeille?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille' => 'سلة المهملات',

	// E
	'effacer' => 'حذف',

	// R
	'readme' => 'تتيح هذه الصفحة {{الحذف النهائي}} لأي مستند تم رميه في سلة المهملات. يمكن ترك اي مستند في السلة حسب الرغبة. {{عليك انت}} بإفراغها متى شئت.',

	// V
	'voir_detail' => 'انظر التفاصيل' # MODIF
);
