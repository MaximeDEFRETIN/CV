<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/pages?lang_cible=fa
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_page' => ' براي الأن هيچ صفحه‌ي نيست', # MODIF

	// C
	'convertir_article' => 'تبديل به يك مقاله',
	'convertir_page' => 'تبديل به يك صفحه',
	'creer_page' => 'آفرينش يك صفحه‌ي نو',

	// M
	'modifier_page' => 'اصلاح صفحه: ', # MODIF

	// P
	'pages_uniques' => 'صفحه‌هاي تك',

	// T
	'titre_page' => 'صفحه',
	'toutes_les_pages' => 'تمام صفه‌ها'
);
