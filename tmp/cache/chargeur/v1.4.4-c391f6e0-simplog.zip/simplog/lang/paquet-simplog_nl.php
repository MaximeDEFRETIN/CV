<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-simplog?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'simplog_description' => 'Wanneer deze plugin wordt geactiveerd, krijgt de beheerder toegang tot alle beschikbare logs van de site. Deze optie is terug te vinden in het onderhoudsmenu.',
	'simplog_nom' => 'Eenvoudige Logs',
	'simplog_slogan' => 'Toegang voor beheerders tot de logs van SPIP'
);
