<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-article_accueil?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'article_accueil_description' => 'This plugin allows you to assign an article as home of a section. Field "id_article_accueil" can then be used by the skeletons.',
	'article_accueil_nom' => 'Home article',
	'article_accueil_slogan' => 'Assign a home article to a section'
);
