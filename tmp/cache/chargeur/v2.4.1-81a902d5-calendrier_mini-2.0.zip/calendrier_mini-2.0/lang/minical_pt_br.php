<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/minical?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'aucune_date' => 'Sem eventos neste mês',

	// C
	'config_titre_calendriermini' => 'Mini-Calendário',

	// L
	'label_affichage_hors_mois' => 'Dias exibidos',
	'label_affichage_hors_mois_0' => 'Ocultar os dias dos meses anterior e seguinte',
	'label_affichage_hors_mois_1' => 'Exibir os dias dos meses anterior e seguinte',
	'label_changement_rapide' => 'Navigação',
	'label_changement_rapide_0' => 'Desativar a seleção rápida do mês ou do ano',
	'label_changement_rapide_1' => 'Ativar a seleção rápida do mês ou do ano',
	'label_format_jour' => 'Formato dos dias',
	'label_format_jour_abbr' => 'Curto',
	'label_format_jour_initiale' => 'Initial',
	'label_jour1' => 'Primeiro dia da semana',

	// M
	'mois_precedent' => 'Mês anterior',
	'mois_suivant' => 'Mês seguinte'
);
