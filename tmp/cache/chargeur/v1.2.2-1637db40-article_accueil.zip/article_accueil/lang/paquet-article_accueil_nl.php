<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-article_accueil?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'article_accueil_description' => 'Met deze plugin kun je een introductie-artikel aan een rubriek toewijzen. Het veld id_article_accueil kan daarna in een skelet worden gebruikt.',
	'article_accueil_nom' => 'Introductie-artikel',
	'article_accueil_slogan' => 'Een introductie-artikel aan rubrieken toewijzen'
);
