<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-saisies?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Este plugin permite facilitar la redacción de campos de formularios proponiendo una etiqueta #SAISIE. El HTML generado es compatible con la nomenclatura de los formularios propuestos por SPIP > 2.0 y con el plugin de configuración CFG.',
	'saisies_nom' => 'Entradas para formularios',
	'saisies_slogan' => 'Escribir fácilmente los campos de formularios.',
	'saisies_titre' => 'Entradas para formularios'
);
