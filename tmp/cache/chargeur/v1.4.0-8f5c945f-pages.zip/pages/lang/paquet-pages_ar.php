<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-pages?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'pages_description' => 'هذا البرنامج المساعد يسمح لك إنشاء صفحات من البنود التي لا ترتبط بأي تسلسل معين. بيد أنها قد تترافق مع اسم القالب
يأذن للإنشاء صفحة من المعلومات القانونية ، من نحن ، اتصال ، وما إلى ذلك.
',
	'pages_slogan' => ' '
);
