<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/corbeille?lang_cible=it
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'corbeille' => 'Cestino',

	// E
	'effacer' => 'Elimina',

	// R
	'readme' => 'Questa pagina consente di {{eliminare definitivamente}} tutti i documenti che hai inviato nel cestino. Puoi lasciare un documento nel cestino per tutto il tempo che vuoi. La cancellazione non è effettuata automaticamente ma {{quando decidi tu}}.',

	// V
	'voir_detail' => 'vedi i dettagli' # MODIF
);
