<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-calendriermini?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'calendriermini_description' => '#CALENDRIER_MINI muestra un calendario en el diseño derivado de dotclear y por lo tanto compatible con los estilos derivados de este sistema de blog.
_ Le son agregados otros elementos como etiquetas, criterios, modelos...',
	'calendriermini_nom' => 'Mini Calendario',
	'calendriermini_slogan' => 'Permite el uso de una etiqueta #CALENDRIER_MINI'
);
