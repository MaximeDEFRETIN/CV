<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/svpstats?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_actualiser_stats' => 'Aktualizovať štatistiky',
	'bulle_actualiser_stats' => 'Aktualizovať štatistiky zásuvných modulov',

	// I
	'info_actualisation_stats_cron' => 'Štatistiky využívania zásuvných modulov sa aktualizujú automaticky každý(ch) @periode@ deň (dní).',
	'info_boite_statistiques' => '<strong>Štatistiky využívania zásuvných modulov ste už aktivovali.</strong><p>Tie sa aktualizujú každý(ch) @periode@ deň (dní). Môžete ich však kedykoľvek aktualizovať aj manuálne.</p>',
	'info_nbr_sites_0' => 'Nevyužíva sa na žiadnej stránke',
	'info_nbr_sites_1' => 'Využíva sa na 1 stránke',
	'info_nbr_sites_n' => 'Využíva sa na @nb@ stránkach'
);
