<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans https://git.spip.net/spip-contrib-extensions/saisies.git
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'saisies_description' => 'Ce plugin permet de faciliter l’écriture de champs de formulaires en proposant une
		balise #SAISIE. Le HTML généré est compatible avec la nomenclature des formulaires
		proposée par SPIP > 2.0 et avec le plugin de configuration CFG.',
	'saisies_nom' => 'Saisies pour formulaires',
	'saisies_slogan' => 'Écrire facilement des champs de formulaires.',
	'saisies_titre' => 'Saisies pour formulaires'
);
