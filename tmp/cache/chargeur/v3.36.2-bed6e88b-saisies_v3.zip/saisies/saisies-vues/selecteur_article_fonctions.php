<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

include_spip('prive/formulaires/selecteur/selecteur_fonctions');
