<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-simplog?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'simplog_description' => 'Once the plugin is enabled, administrators can look at all available logs on the site. A maintenance menu entry allows to access the consultation page.',
	'simplog_nom' => 'Simples Logs',
	'simplog_slogan' => 'Analyze SPIP’s logs by administrators'
);
